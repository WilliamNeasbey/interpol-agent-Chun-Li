Game: Kingdom Hearts (PS2)
Model: Destiny Islands - Seashore (di00_01)
Ripped by: Murugo (@MurugalStudio)

Credits:
. CrazyCatz00 - KH1 ISOTools (Unpacker)
. Revelation - KH .MDLS plugin for Noesis
